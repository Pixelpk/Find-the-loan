<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12 ">
                <h4>T: +(011) 333 66688 </h4>
                <h5 > info@findtheloan.com</h5>
                <ul class="social-icons text-left">
                    <li><a class="facebook text-white" href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a class="twitter text-white" href="#"><i class="fab fa-twitter"></i></i></a></li>
                </ul>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <h6>Site Map</h6>
                <ul class="footer-links">

                    <li><a href="/">Home </a></li>
                    <li><a href="/">About Us</a></li>
                    <li><a href="/">Faq's</a></li>
                    <li><a href="/">Contact Us</a></li>
                </ul>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <h6>Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="/">In the news </a></li>
                    <li><a href="/">Why use a digital loan consultant</a></li>
                    <li><a href="/">Calculators</a></li>
                    <li><a href="/">Glossary of products</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12 align-self-center align-items-center">
                <h6></h6>
                <ul class="footer-links">
                    <li><a href="/">Privacy Policy </a></li>
                    <li><a href="/">Terms & Conditions</a></li>
                </ul>
            </div>
        </div>
        <hr>
    </div>


    <div class="container">
        <div class="row text-center">
            <div class="col-sm-12 col-md-12">
                <h6>Company registrations number: FA4587963527</h6>
                <p class=" text-center footerpara">Scanfcode.com <i>CODE WANTS TO BE SIMPLE </i> is an initiative  to help the upcoming programmers with the code. Scanfcode focuses on providing the most efficient code or snippets as the code wants to be simple. We will help programmers build up concepts in different programming languages that include C, C++, Java, HTML, CSS, Bootstrap, JavaScript, PHP, Android, SQL and Algorithm.Scanfcode.com <i>CODE WANTS TO BE SIMPLE </i> is an initiative  to help the upcoming programmers with the code. Scanfcode focuses on providing the most efficient code or snippets as the code wants to be simple. We will help programmers build up concepts in different programming languages that include C, C++, Java, HTML, CSS, Bootstrap, JavaScript, PHP, Android, SQL and Algorithm.Scanfcode.com <i>CODE WANTS TO BE SIMPLE </p>
            </div>
        </div>
    </div>
</footer>
