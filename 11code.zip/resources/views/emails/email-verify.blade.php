<b>Email verify link</b>
<br>
<a href="{{ url('/verify?email=') }}{{ $email }}">{{ $email }}</a>