<?php

namespace App\Http\Livewire\Cms;

use Livewire\Component;

class ContactUsComponent extends Component
{
    public function render()
    {
        return view('livewire.cms.contact-us-component');
    }
}
