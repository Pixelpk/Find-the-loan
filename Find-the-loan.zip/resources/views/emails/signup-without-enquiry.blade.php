<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Incomplete Signup reminder</title>
</head>
<body>
    Hi {{ $first_name." ".$last_name}}, 
     
    <p>Hey we noticed you have not made any enquires. Were you just trying us out? </p>
    <p>We believe you will love it when the times comes.</p> 
    <p>Meanwhile perhaps you like to look at our referral program instead?</p>
    
    <p>Thanks,</p>

</body>
</html>