<div>
  <div class="breadcrumb-wrapper">

    <div class="breadcrumb-wrapper-overlay"></div>
    
    <!--begin container -->
    <div class="container sec-container">
    
        <!--begin row -->
        <div class="row">
    
            <!--begin col-xs-12 -->
            <div class="col-sm-12 col-lg-12 col-xs-12">
    
                <h2 class="page-title white text-center">About Us</h2>
    
            </div>
    
    
            <!--end col-xs-12 -->
    
        </div>
        <!--end row -->
    
    </div>
    <!--end container -->
    
    </div>
    <!--end breadcrumb-wrapper-->
  <section class="section-white-services" id="about">
      <img
      class="about-bg"
      src="{{ asset('assets/cms/img/Home/about-bg1.jpg') }}"
      alt=""
    >
      <div class="container position-relative">
          <div class="row">
              <div class="about-content mx-auto w-75">
                  <h2 class="fw-bold text-center">About Us</h2>
            <p class="lead">  {!! $about_us->value !!}</p>
              </div>
          </div>
          <!-- <div class="row">
              <div class="col-md-12">
              {!! $financial_inclusion->value !!}
              </div>
          </div> -->
      </div>
  </section>
</div>