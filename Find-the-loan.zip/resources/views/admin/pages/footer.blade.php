<footer class="footer">
    © 2021 Find the loan <span class="d-none d-sm-inline-block"> - Powered by <i class="mdi mdi-heart text-danger"></i> Pixelpk Technologies</span>.
</footer>
