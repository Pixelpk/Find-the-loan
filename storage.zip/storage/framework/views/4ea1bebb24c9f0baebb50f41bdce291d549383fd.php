<div>
    <?php
    $main_types = loanProfile();
    ?>
    <section class="section-white small-padding" style="margin-top: 50px;">
        <div class="container">
            <div class="card" style="margin-top:30px;">
                <div class="card-body">
                    <ul class="nav nav-pills">
                        <li class="nav-item">
                            <a wire:click="$set('tab', '1')" style="padding: .1rem 1rem;"
                                class="nav-link <?php echo e($tab == '1' ? 'active' : ''); ?>" aria-current="page" href="#">LOAN
                                TYPE</a>
                        </li>
                        <li class="nav-item">
                            <a wire:click="$set('tab', '8')" style="padding: .1rem 1rem;"
                                class="<?php echo e(!$main_type || !$loan_type_id ? 'disabled' : ''); ?> nav-link <?php echo e($tab == '8' ? 'active' : ''); ?>"
                                aria-current="page" href="#">LOAN TYPE DETAIL
                            </a>
                        </li>

                         

                        <li class="nav-item">
                            <a wire:click="$set('tab', '4')" style="padding: .1rem 1rem;"
                                class="<?php echo e(!$comDisable ? 'disabled' : ''); ?> nav-link <?php echo e($tab == '4' ? 'active' : ''); ?>"
                                href="#">COMPANY DETAIL</a>
                        </li>

                        <?php if(!$this->listed_company_check): ?>
                        <li class="nav-item">
                            <a wire:click="$set('tab', '5')" style="padding: .1rem 1rem;"
                                class="<?php echo e(!$documentDisable ? 'disabled' : ''); ?> nav-link <?php echo e($tab == '5' ? 'active' : ''); ?>"
                                href="#">COMPANY DOCUMENTS</a>
                        </li>
                        <?php endif; ?>

                            
                        <?php if(sizeof($get_share_holder_type) > 0 && !$this->listed_company_check): ?>
                        <li class="nav-item">
                            <a wire:click="$set('tab', '7')" style="padding: .1rem 1rem;"
                                class="<?php echo e(!$shareDisable ? 'disabled' : ''); ?> nav-link <?php echo e($tab == '7' ? 'active' : ''); ?>"
                                href="#">SHAREHOLDER</a>
                        </li>
                            
                        <?php endif; ?>


                        <?php if(!$lenderflag): ?>
                        <li class="nav-item">
                            <a style="padding: .1rem 1rem;" class="disabled nav-link <?php echo e($tab == '9' ? 'active' : ''); ?>"
                                href="#">LENDER</a>
                        </li>
                        <?php elseif($lenderflag): ?>
                        <li class="nav-item">
                            <a wire:click="$set('tab', '9')" style="padding: .1rem 1rem;"
                                class=" nav-link <?php echo e($tab == '9' ? 'active' : ''); ?>" href="#">LENDER</a>
                        </li>
                        <?php endif; ?>

                        
                    </ul>
                    <br>
                    <br>
                    <?php if(session('gernalMessage')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e(session('gernalMessage')); ?>

                    </div>
                    <?php endif; ?>
                    <div wire:ignore>
                        <input  type="hidden" class="form-control" id="ship-address" >
                    </div>
                    <?php if($tab == 8): ?>
                   
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('widget.renovation', ['loan_type_id' => $loan_type_id, "main_type" => $main_type])->html();
} elseif ($_instance->childHasBeenRendered('vekySAO')) {
    $componentId = $_instance->getRenderedChildComponentId('vekySAO');
    $componentTag = $_instance->getRenderedChildComponentTagName('vekySAO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vekySAO');
} else {
    $response = \Livewire\Livewire::mount('widget.renovation', ['loan_type_id' => $loan_type_id, "main_type" => $main_type]);
    $html = $response->html();
    $_instance->logRenderedChild('vekySAO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php endif; ?>
                    <?php if($tab == 1): ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label for="">Select Profile</label>
                            <select style="margin-top: 10px;" wire:model="main_type" class="form-select"
                                aria-label="Default select example" wire:change="getMainType()">
                                <option value="" hidden>Select</option>
                                <option value="1">Business</option>
                                <option value="2">Consumer</option>
                            </select>
                        </div>
                    </div>
                    <?php if(sizeof($mainTypes) > 0): ?>
                    <div class="row">
                        <?php $__currentLoopData = $mainTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3" style="padding-top:30px;">
                            <div class="list-group">
                                <a href="#" class="custmbtn list-group-item list-group-item-action active">
                                    <?php echo e($item->main_type); ?>

                                </a>
                                <?php $__currentLoopData = $item->subTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="list-group-item list-group-item-action">
                                    <div class="form-check form-switch">
                                        <input wire:model="values.<?php echo e($subType->id); ?>"
                                            wire:click="getLoanReason(<?php echo e($subType->id); ?>, <?php echo e($key); ?>)"
                                            class="form-check-input singleCheck" type="checkbox" />
                                        <label class="form-check-label"
                                            for="<?php echo e($subType->id); ?>"><?php echo e($subType->sub_type); ?></label>
                                    </div>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                    <?php endif; ?>
                    
        
        <?php elseif($tab == 9): ?>
        <?php $NFL = [1,2,3,4]
        ?>
        
<div class="row">
    <div class="col-md-8">
        <?php $__currentLoopData = $NFL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-8" style="margin-top: 30px;">
                <b>
                    <?php if($item == 1): ?>
                    Bank
                    <?php elseif($item == 2): ?>
                    Excluded Moneylender
                    <?php elseif($item == 3): ?>
                    Fintech
                    <?php else: ?>
                    Moneylender
                    <?php endif; ?>
                </b>
            </div>
            <div class="col-md-4" style="margin-top: 30px;">
                <div class="form-check">
                    <input wire:model="checkSelect.<?php echo e($item); ?>" wire:change="Selectall(<?php echo e($item); ?>)"
                        class="form-check-input" type="checkbox" value="" id="<?php echo e($item); ?>">
                    <label class="form-check-label" for="<?php echo e($item); ?>">
                        <b> Select All</b>
                    </label>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $financePartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financePartner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($financePartner->type == 1 && $item == 1): ?>
            <div class="col-md-4" style="margin-top:30px;">
                <div class="form-check">
                    <input wire:model="lender.<?php echo e($financePartner->id); ?>" class="form-check-input" type="checkbox"
                        value="" id="<?php echo e($financePartner->id); ?>">
                    <label class="form-check-label" for="<?php echo e($financePartner->id); ?>">
                        <img for="<?php echo e($financePartner->id); ?>"
                            src="uploads/financePartnerImages/<?php echo e($financePartner->image); ?>" alt="" width="80px"
                            height="25px">
                    </label>
                </div>
            </div>
            <?php elseif($financePartner->type == 2 && $item == 2): ?>
            <div class="col-md-4" style="margin-top:30px;">
                <div class="form-check">
                    <input wire:model="lender.<?php echo e($financePartner->id); ?>" class="form-check-input" type="checkbox"
                        value="" id="<?php echo e($financePartner->id); ?>">
                    <label class="form-check-label" for="<?php echo e($financePartner->id); ?>">
                        <img for="<?php echo e($financePartner->id); ?>"
                            src="uploads/financePartnerImages/<?php echo e($financePartner->image); ?>" alt="" width="80px"
                            height="25px">
                    </label>
                </div>
            </div>
            <?php elseif($financePartner->type == 3 && $item == 3): ?>
            <div class="col-md-4" style="margin-top:30px;">
                <div class="form-check">
                    <input wire:model="lender.<?php echo e($financePartner->id); ?>" class="form-check-input" type="checkbox"
                        value="" id="<?php echo e($financePartner->id); ?>">
                    <label class="form-check-label" for="<?php echo e($financePartner->id); ?>">
                        <img for="<?php echo e($financePartner->id); ?>"
                            src="uploads/financePartnerImages/<?php echo e($financePartner->image); ?>" alt="" width="80px"
                            height="25px">
                    </label>
                </div>
            </div>
            <?php elseif($financePartner->type == 4 && $item == 4): ?>
            <div class="col-md-4" style="margin-top:30px;">
                <div class="form-check">
                    <input wire:model="lender.<?php echo e($financePartner->id); ?>" class="form-check-input" type="checkbox"
                        value="" id="<?php echo e($financePartner->id); ?>">
                    <label class="form-check-label" for="<?php echo e($financePartner->id); ?>">
                        <img for="<?php echo e($financePartner->id); ?>"
                            src="uploads/financePartnerImages/<?php echo e($financePartner->image); ?>" alt="" width="80px"
                            height="25px">
                    </label>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-4">
        <div class="row">
            <div class="col-md-12">
                <div class="form-check form-switch">
                    <input wire:change="getCbsLender()" wire:model="cbs_member" class="form-check-input" type="checkbox"
                        id="flexSwitchCheckChecked4">
                    <label class="form-check-label" for="flexSwitchCheckChecked4">Show only CBS members</label>
                </div>
                <br>
            </div>
            <?php if($cbs_member): ?>
            <div class="col-md-6">
                <p>
                    <b>CBS</b>(Downloaded Within The Last 30 days)

                </p>
            </div>
            <div class="col-md-6">
                <input wire:model="cbs_member_image" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                    type="file" id="vehicleimage">
                <?php $__errorArgs = ['cbs_member_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color:red;">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>
            <div class="col-md-12">
                <br>
                <div class="form-check form-switch">
                    <input wire:model="financial_institute" class="form-check-input" type="checkbox"
                        id="flexSwitchCheckChecked4">
                    <label class="form-check-label" for="flexSwitchCheckChecked4"> <b>Show only Enterprise Financing
                            Scheme Participating Financial Institutes</b></label>
                </div>
            </div>

        </div>
    </div>
    <div class="col-md-12">
        <br>
        <button wire:loading.attr='disabled' class="btn" type="button" wire:target='storeLender'
            wire:click.prevent='storeLender'>
            <div wire:loading wire:target="storeLender">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            </div>
            Submit
        </button>
    </div>

</div>



<?php elseif($tab == 3): ?>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">
        <label for="amount" class="form-label">AMOUNT</label>
        <input wire:model="amount" type="number" class="form-control" id="amount">
        <?php if(session('sessionMessage')): ?>
        <div style="color:red;">
            <?php echo e(session('sessionMessage')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <br>
        <button wire:loading.attr='disabled' class="btn" type="button" wire:target='companyDetail'
            wire:click.prevent='companyDetail'>
            <div wire:loading wire:target="companyDetail">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            </div>
            Save & Continue
        </button>

    </div>
</div>
<?php elseif($tab == 4): ?>

<div class="row">
    <div class="col-md-12" style="margin-top: 40px;">
        <div class="form-check form-switch">
            <input wire:model="listed_company_check" class="form-check-input" type="checkbox"
                id="flexSwitchCheckDefault">
            <label class="form-check-label" for="flexSwitchCheckDefault">This is a listed
                company</label>
        </div>
    </div>
    <?php if(!$listed_company_check): ?>
    <div class="col-md-5" style="margin-top:20px;margin-bottom:20px;">
        <label for="company_year">When was the company incorporated?
        </label>
        <div class="input-group">
            
            <select wire:model="company_years" class="form-select" aria-label="Default select example"
                wire:change="getnoofYear()">
                <option value="" hidden>Select</option>
                <?php for($x = 1990; $x <= date('Y'); $x++): ?> <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                    <?php endfor; ?>
            </select>
            &nbsp;&nbsp;<p style="padding-top:10px;">Years</p>

        </div>
        <?php $__errorArgs = ['company_years'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-3" style="margin-top:20px;margin-bottom:20px;">
        <div class="input-group" style="margin-top:20px;">
            <select wire:model="company_months" class="form-select" aria-label="Default select example"
                wire:change="getnoofYear()">
                <option value="" hidden>Select</option>
                <?php for($x = 01; $x <= 11; $x++): ?> <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                    <?php endfor; ?>
            </select>
            &nbsp;&nbsp;<p style="padding-top:10px;">Months</p>
            <?php $__errorArgs = ['company_months'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-4"></div>

    <div class="col-md-12" style=""><b>OR</b></div>
    <div class="col-md-5" style="margin-top: 30px;">
        <label for="company_year" class="form-label">How long has the company been in
            business?</label>
        <div class="input-group">
            <input wire:keyup="resetComapny" placeholder="Number of years" wire:model="company_year" type="number"
                class="form-control" aria-label="Text input with dropdown button">
            &nbsp;&nbsp;<p style="padding-top:10px;">Years</p>
        </div>
        <?php $__errorArgs = ['company_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-3" style="margin-top: 30px;">
        <div class="input-group" style="margin-top:29px;">
            <input wire:keyup="resetComapny" placeholder="Number of month" wire:model="company_month" type="number"
                class="form-control" aria-label="Text input with dropdown button">
            &nbsp;&nbsp;<p style="padding-top:10px;">Months</p>
        </div>
        <?php $__errorArgs = ['company_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label for="percentage_shareholder" class="form-label">% of local shareholding
        </label>
        <div class="input-group mb-3">
            <div class="input-group-prepend">

            </div>
            <input wire:model="percentage_shareholder" type="number" class="form-control" id="percentage_shareholder">
            <div class="input-group-append">
                <span class="input-group-text">%</span>
            </div>
        </div>

        <?php $__errorArgs = ['percentage_shareholder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label for="number_of_share_holder" class="form-label">Number of shareholder including
            parent
            company if any
        </label>
        <input max="10" wire:model="number_of_share_holder" type="number" class="form-control"
            id="number_of_share_holder">
        <?php $__errorArgs = ['number_of_share_holder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label class="form-label">Company structure type</label>
        <select wire:model="company_structure_type_id" class="form-select" aria-label="Default select example">
            <option value="" hidden>Select</option>
            <?php $__currentLoopData = $company_structure_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->structure_type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['company_structure_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label class="form-label" for="">Sector</label>
        <select wire:model="sector_id" class="form-select" aria-label="Default select example">
            <option value="" hidden>Select</option>
            <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['sector_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label for="number_of_employees" class="form-label">Number of full-time employee
        </label>
        <input wire:model="number_of_employees" type="number" class="form-control" id="number_of_employees">
        <?php $__errorArgs = ['number_of_employees'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6" style="margin-top: 30px;">
        <label for="revenue" class="form-label">Revenue (rounded up is fine)</label>
        <div class="input-group">
            <input placeholder="$" wire:model="revenue" type="number" class="form-control"
                aria-label="Text input with dropdown button">

        </div>
        <?php $__errorArgs = ['revenue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6" style="margin-top: 30px;">
        <label for="company_name" class="form-label">COMPANY NAME</label>
        <input wire:model="company_name" type="text" class="form-control" id="company_name">
        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6" style="margin-top: 30px;">
        <label for="website" class="form-label">Company website (if available)</label>
        <input wire:model="website" type="text" class="form-control" id="website">
        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <?php else: ?>
    <div class="col-md-12" style="margin-top: 30px;">
        <label for="company_name" class="form-label">Please provide either parent company name or
            its ticker number followed by which stock exchange</label>
        <input wire:model="company_name" type="text" class="form-control" id="company_name">
        <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div style="color: red;">
            <?php echo e($message); ?>

        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-12" style="margin-top:30px;">
        <div class="form-group">
            <label for="company_name" class="form-label">Country</label>
            <select wire:model="country" class="form-select" aria-label="Default select example">
                <option value="" hidden>Select</option>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-4 text-left">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">
            <div class="form-group">

                <label class="control-label mb-10">
                    Subsidiary’s (borrower)M&AA
                </label>
                <br>
                <br>
                <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                    <input wire:model="subsidiary" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                        type="file" id="vehicleimage">
                </label>
            </div>
            <?php $__errorArgs = ['subsidiary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<div class="row">
    <div class="col-12">
        <br>
        <button class="btn" type="button" wire:target='confirmationMessage' wire:click.prevent='confirmationMessage'>
            <div wire:loading wire:target="confirmationMessage">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            </div>
            Save & Continue
        </button>

    </div>
</div>
<?php elseif($tab == 5): ?>
<?php if(!$listed_company_check): ?>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">
        <b>6 months latest bank statement</b>
        <p>If It’s on or Over The 8th Of The Current Month For Example 8th Jan, You Would Need To
            Submit
            from Dec And Not Nov As The Latest Months. For companies less than 6 months old or
            unprofitable do check out our FAQ here.</p>
    </div>

    <?php for($x = 1; $x < 8; $x++): ?> <div class="col-md-3" style="margin-top: 30px;">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">
            <div class="form-group">
                <label class="control-label mb-10">
                    <?php echo date("M", strtotime( date( 'Y-m-01' )." -$x months")) ?>

                    <?php if(1 == $x): ?> (Optional) <?php endif; ?>
                </label>
                <br>
                <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                    <input wire:model="photo.<?php echo e(date("M", strtotime( date( 'Y-m-01' )." -$x months"))); ?>"
                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                        id="vehicleimage" name="" id="">
                </label>
            </div>
            <?php $__currentLoopData = array_unique($errorArray); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($error == date("M", strtotime( date( 'Y-m-01' )." -$x months"))): ?>
            <div class="text-danger">
                <?php echo e($error. ' month required'); ?>

            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
</div>
<?php endfor; ?>

<b><br>OR</b>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">

        <b>Consolidated Statement.</b>
        <p>If Your Statement Is Not Spilt Between Months But One</p>
    </div>
    <div class="col-md-4 text-left">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">

            <div class="form-group">
                <label class="control-label mb-10">

                </label>

                <br>
                <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                    <input wire:model="statement" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                        type="file" id="vehicleimage" name="" id="">

                </label>
            </div>
            <?php $__errorArgs = ['statement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
    </div>
</div>
<hr>
<div class="row">

    <div class="col-md-12" style="margin-top: 30px;">
        <b>Latest <?php echo e($getNumberOfCompanyYears >= 3 ? '2' : '1'); ?> Years Financial Statement</b>
        <p>
            (Income Statement also known as Profit & Loss
            + Statement of financial position also known as Balance Sheet)
        </p>
    </div>
    <div class="col-md-4 text-left" style="margin-top: 30px;">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">

            <div class="form-group">
                <label class="control-label mb-10">
                    <label for="">Latest year</label>
                </label>

                <br>
                <input wire:model="latest_year" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                    type="file" id="vehicleimage" name="" id="">

            </div>
            <?php $__errorArgs = ['latest_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
    </div>
    <?php if($getNumberOfCompanyYears >= 3): ?>
    <div class="col-md-3 text-left" style="margin-top: 30px;">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">
            <div class="form-group">
                <label class="control-label mb-10">
                    <label for="">Before year</label>
                </label>
                <br>
                <input wire:model="year_before" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                    type="file" id="vehicleimage" name="" id="">
            </div>
            <?php $__errorArgs = ['year_before'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<hr>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">
        <b>Profitable for the last 2 accounting years</b>
    </div>
    <div class="col-md-4" style="margin-top: 30px;">
        <div class="form-group">
            <select wire:model="profitable_latest_year" class="form-select" aria-label="Default select example">
                <option value="" hidden>Select</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
            <?php $__errorArgs = ['profitable_latest_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-4" style="margin-top: 30px;">
        <div class="form-group">
            <select wire:model="profitable_before_year" class="form-select" aria-label="Default select example">
                <option value="" hidden>Select</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
            <?php $__errorArgs = ['profitable_before_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

</div>
<hr>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">
        <b style="color: grey;">Optional info</b>
    </div>
    <div class="col-md-12" style="margin-top: 30px;">
        <b>Current Year.</b>
        <p>If you are <b>more than 3-6 months into your current accounting year,</b> and if your
            management account(drafts/unaudited) pulls up the average, providing them may be helpful
        </p>
    </div>
    <div class="col-md-3 text-left">
        <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
            x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
            x-on:livewire-upload-progress="progress = $event.detail.progress">
            <div class="form-group">
                <label class="control-label mb-10">
                </label>
                <br>
                <input wire:model="current_year" accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                    type="file" id="vehicleimage" name="" id="">
            </div>
            <?php $__errorArgs = ['current_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;text-align:center">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div x-show="isUploading">
                <progress max="100" x-bind:value="progress"></progress>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12" style="margin-top: 30px;">
        <b>Revenue (rounded up is fine)</b>
    </div>
    <div class="col-md-3" style="margin-top: 30px;">
        <div class="form-group">
            <input type="number" class="form-control" wire:model="optional_revenuee">
            <?php $__errorArgs = ['optional_revenuee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div style="color: red;">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>
<hr>
<div class="col-12">
    <br>
    <button class="btn" type="button" wire:target='saveCompanyDocuments' wire:click.prevent='saveCompanyDocuments'>
        <span wire:loading wire:target="saveCompanyDocuments" class="spinner-border spinner-border-sm" role="status"
            aria-hidden="true"></span>
        Save & Continue
    </button>
</div>
</div>
<?php endif; ?>

    <?php elseif($tab == 7): ?>
    <?php $srno = 1; ?>
    <?php $no = 1; ?>
    <div class="row">
        <?php $__currentLoopData = $get_share_holder_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6" style="margin-top: 40px;">
            <div class="form-check form-switch">
                <label class="form-check-label" for="flexSwitchCheckDefault">Shareholder <?php echo e($key++); ?>

                </label>
            </div>
        </div>
        <div class="col-md-6">

            <div class="form-check" style="margin-top: 40px;">
                <select wire:model="checkShareHolder.<?php echo e($item['id']); ?>"
                    wire:change="getShareholderTypeId(<?php echo e($item['id']); ?>)">
                    <option value="0">Person</option>
                    <option value="1">Company</option>
                </select>
                
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div id="accordion" style="margin-top: 30px;">
        <?php $__currentLoopData = $get_share_holder_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['share_holder_type'] == 1): ?>
        <div class="card">
            <?php $shreholder = $item['id'] ?>
            <div class="card-header" id="<?php echo e($shreholder); ?>" style="padding:10px;">
                <h5 class="mb-0">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($shreholder); ?>"
                        aria-expanded="true" aria-controls="collapseOne<?php echo e($shreholder); ?>">
                        Shareholder Person <?php echo e($key++); ?>

                    </button>
                </h5>
            </div>
            <div wire:ignore.self style="margin-top: 30px;" id="collapseOne<?php echo e($shreholder); ?>"
                class="collapse <?php echo e($key == 0 ? 'show' : ''); ?>" aria-labelledby="<?php echo e($shreholder); ?>"
                data-parent="#accordion">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <b>NRIC</b> or <b>Passport/Identity Card</b> ( Foreigner)
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <br>
                                    <label for="">NRIC Front</label>
                                    <input wire:model="nric_front.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["nric_front.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <br>
                                    <label for="">NRIC Back</label>
                                    <input wire:model="nric_back.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["nric_back.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <br>
                                    <label for="">Passport</label>
                                    <input wire:model="passport.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["passport.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>Personal NOA</b>
                            <p>(Notice of Assessment) 2 Years</p>
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <br>
                                    <label for="">Latest</label>
                                    <input wire:model="nao_latest.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["nao_latest.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <br>
                                    <label for="">Older</label>
                                    <input wire:model="nao_older.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["nao_older.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>I don't have income proof because i am</b>
                        </div>
                        <div class="col-md-4" style="margin-top:30px;">
                            <select class="form-control" name="" id="" wire:model.defer="not_proof.<?php echo e($shreholder); ?>">
                                <option value="" hidden>Select</option>
                                <option value="1">Student</option>
                                <option value="2">Homemaker</option>
                                <option value="3">Retired</option>
                                <option value="4">Unemployed</option>
                            </select>
                            <?php $__errorArgs = ["not_proof.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <br>
                            <button class="btn" type="button" wire:target='share_holder_document_store'
                                wire:click.prevent='share_holder_document_store(<?php echo e($item['id']); ?>)'>
                                <span wire:loading wire:target="share_holder_document_store"
                                    class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                Save & Continue
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <?php $shreholder = $item['id'] ?>
            <div class="card-header" id="<?php echo e($shreholder); ?>" style="padding:10px;">
                <h5 class="mb-0">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne<?php echo e($shreholder); ?>"
                        aria-expanded="true" aria-controls="collapseOne<?php echo e($shreholder); ?>">
                        Shareholder Company <?php echo e($key++); ?>

                    </button>
                </h5>
            </div>
            <div wire:ignore.self id="collapseOne<?php echo e($shreholder); ?>" class="collapse" aria-labelledby="<?php echo e($shreholder); ?>"
                data-parent="#accordion">
                <div class="card-body">
                    <ul class="nav nav-pills">


                        <li class="nav-item">
                            <a wire:click="$set('subtab', '1')" style="padding: .1rem 1rem;"
                                class="nav-link <?php echo e($subtab == '1' ? 'active' : ''); ?>" href="#">SHAREHOLDER
                                COMPANY
                                DETAIL</a>
                        </li>
                        <?php if(!$chklsit[$shreholder]): ?>
                        <li class="nav-item">
                            <a wire:click="$set('subtab', '2')" style="padding: .1rem 1rem;"
                                class="<?php echo e(!$shareholderCompany ? 'disabled' : ''); ?> nav-link <?php echo e($subtab == '2' ? 'active' : ''); ?>"
                                href="#">SHAREHOLDER
                                COMPANY
                                DOCUMENTS</a>
                        </li>
                        <?php endif; ?>



                    </ul>
                    <?php if($subtab == 1): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <br>
                            <br>
                            <div class="form-check form-switch">
                                <input wire:change="get_company_listed(<?php echo e($shreholder); ?>)"
                                    wire:model="share_holder_listed_company_check.<?php echo e($shreholder); ?>"
                                    class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                                <label class="form-check-label" for="flexSwitchCheckDefault">This is a
                                    listed
                                    company</label>
                            </div>
                        </div>
                    </div>
                    <?php if(!$chklsit[$shreholder]): ?>
                    <div class="row" style="margin-top:30px;">



                        <div class="col-md-5" style="margin-top: 30px;">
                            <label for="share_holder_company_year.<?php echo e($shreholder); ?>" class="form-label">How long has the
                                company
                                been in
                                business?</label>
                            <div class="input-group">
                                <input wire:click="shareHolderResetComapny(<?php echo e($shreholder); ?>)"
                                    placeholder="Number of years"
                                    wire:model="share_holder_company_year.<?php echo e($shreholder); ?>" type="number"
                                    class="form-control" aria-label="Text input with dropdown button">
                                &nbsp;&nbsp;<p style="padding-top:10px;">Years</p>
                            </div>
                            <?php $__errorArgs = ["share_holder_company_year.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3" style="margin-top: 30px;">
                            <div class="input-group" style="margin-top:29px;">
                                <input wire:click="shareHolderResetComapny(<?php echo e($shreholder); ?>)"
                                    placeholder="Number of month"
                                    wire:model="share_holder_company_month.<?php echo e($shreholder); ?>" type="number"
                                    class="form-control" aria-label="Text input with dropdown button">
                                &nbsp;&nbsp;<p style="padding-top:10px;">Months</p>
                            </div>
                            <?php $__errorArgs = ["share_holder_company_month.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12" style="margin-top:20px;margin-bottom:20px;"><b>OR</b></div>
                        <div class="col-md-5">
                            <label for="share_holder_company_years.<?php echo e($shreholder); ?>">When was the company incorporated?
                            </label>
                            <div class="input-group">
                                
                                <select
                                    <?php echo e(isset($share_holder_company_year[$shreholder]) || isset( $share_holder_company_month[$shreholder]) ? 'disabled' : ''); ?>

                                    wire:model="share_holder_company_years.<?php echo e($shreholder); ?>" class="form-select"
                                    aria-label="Default select example">
                                    <option value="" hidden>Select</option>
                                    <?php for($x = 1990; $x <= date('Y'); $x++): ?> <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>
                                        <?php endfor; ?>
                                </select>
                                &nbsp;&nbsp;<p style="padding-top:10px;">Years</p>

                            </div>
                            <?php $__errorArgs = ["share_holder_company_years.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-3">
                            <div class="input-group" style="margin-top:20px;">
                                <select
                                    <?php echo e(isset($share_holder_company_year[$shreholder]) || isset( $share_holder_company_month[$shreholder]) ? 'disabled' : ''); ?>

                                    wire:model="share_holder_company_months.<?php echo e($shreholder); ?>" class="form-select"
                                    aria-label="Default select example">
                                    <option value="" hidden>Select</option>
                                    <?php for($x = 01; $x <= 12; $x++): ?> <option value="1"><?php echo e($x); ?></option>
                                        <?php endfor; ?>
                                </select>
                                &nbsp;&nbsp;<p style="padding-top:10px;">Months</p>
                                <?php $__errorArgs = ["share_holder_company_months.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_percentage_shareholder.<?php echo e($shreholder); ?>" class="form-label">% of
                                local
                                shareholding
                            </label>
                            <input wire:model="share_holder_percentage_shareholder.<?php echo e($shreholder); ?>" type="number"
                                class="form-control" id="share_holder_percentage_shareholder.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_percentage_shareholder.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_number_of_share_holder" class="form-label">Number of
                                shareholder including
                                parent
                                company if any
                            </label>
                            <input wire:model="share_holder_number_of_share_holder.<?php echo e($shreholder); ?>" type="number"
                                class="form-control" id="share_holder_number_of_share_holder.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_number_of_share_holder.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label class="form-label">Company structure type</label>
                            <select wire:model="share_holder_company_structure_type_id.<?php echo e($shreholder); ?>"
                                class="form-select" aria-label="Default select example">
                                <option value="" hidden>Select</option>
                                <?php $__currentLoopData = $company_structure_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->structure_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ["share_holder_company_structure_type_id.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label class="form-label" for="">Sector</label>
                            <select wire:model="share_holder_sector_id.<?php echo e($shreholder); ?>" class="form-select"
                                aria-label="Default select example">
                                <option value="" hidden>Select</option>
                                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ["share_holder_sector_id.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_number_of_employees" class="form-label">Number of
                                full-time
                                employee
                            </label>
                            <input wire:model="share_holder_number_of_employees.<?php echo e($shreholder); ?>" type="number"
                                class="form-control" id="share_holder_number_of_employees.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_number_of_employees.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_revenue.<?php echo e($shreholder); ?>" class="form-label">Revenue
                                (rounded up is fine)</label>
                            <div class="input-group">
                                <input placeholder="$" wire:model="share_holder_revenue.<?php echo e($shreholder); ?>" type="number"
                                    class="form-control" aria-label="Text input with dropdown button">
                            </div>
                            <?php $__errorArgs = ["share_holder_revenue.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_company_name" class="form-label">COMPANY NAME</label>
                            <input wire:model="share_holder_company_name.<?php echo e($shreholder); ?>" type="text"
                                class="form-control" id="share_holder_company_name.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_company_name.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="share_holder_website.<?php echo e($shreholder); ?>" class="form-label">Company
                                website (if available)</label>
                            <input wire:model="share_holder_website.<?php echo e($shreholder); ?>" type="text" class="form-control"
                                id="share_holder_website.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_website.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <?php else: ?>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <label for="share_holder_company_name.<?php echo e($shreholder); ?>" class="form-label">Please provide
                                either parent company name or
                                its ticker number followed by which stock exchange</label>
                            <input wire:model="share_holder_company_name.<?php echo e($shreholder); ?>" type="text"
                                class="form-control" id="share_holder_company_name.<?php echo e($shreholder); ?>">
                            <?php $__errorArgs = ["share_holder_company_name.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;">
                                <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-12" style="margin-top:30px;">
                            <div class="form-group">
                                <label for="share_holder_country.<?php echo e($shreholder); ?>" class="form-label">Country</label>
                                <select wire:model="share_holder_country.<?php echo e($shreholder); ?>" class="form-select"
                                    aria-label="Default select example">
                                    <option value="" hidden>Select</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ["share_holder_country.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4 text-left">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">

                                    <label class="control-label mb-10">
                                        Subsidiary’s (borrower)M&AA
                                    </label>
                                    <br>
                                    <br>
                                    <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                                        <input wire:model="share_holder_subsidiary.<?php echo e($shreholder); ?>"
                                            accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                                            type="file" id="vehicleimage">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["share_holder_subsidiary.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endif; ?>
                    <div class="row" class="row">
                        <div class="col-12">
                            <br>
                            <button class="btn" type="button" wire:target='share_holder_document_store'
                                wire:click.prevent='share_holder_document_store(<?php echo e($shreholder); ?>)'>
                                <span wire:loading wire:target="share_holder_document_store"
                                    class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                Save & Continue
                            </button>
                        </div>
                    </div>
                    <?php elseif($subtab == 2): ?>
                    
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 60px;">
                            <b>6 months latest bank statement</b>
                            <p>If It’s on or Over The 8th Of The Current Month For Example 8th Jan, You
                                Would
                                Need To
                                Submit
                                from Dec And Not Nov As The Latest Months. For companies less than 6 months
                                old
                                or
                                unprofitable do check out our FAQ here.</p>
                        </div>
                        <?php for($x = 1; $x <= 7; $x++): ?> <div class="col-md-3" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <label class="control-label mb-10">
                                        <?php echo date("M", strtotime( date( 'Y-m-01' )." -$x months"))
                                        ?>
                                        <?php if(1 == $x): ?> (Optional) <?php endif; ?>
                                    </label>
                                    <br>
                                    <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                                        <input
                                            wire:model="share_holder_photo.<?php echo e($shreholder); ?>.<?php echo e(date("M", strtotime( date( 'Y-m-01' )." -$x months"))); ?>"
                                            accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                                            type="file" id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__currentLoopData = $share_errorArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($error == date("M", strtotime( date( 'Y-m-01' )." -$x months"))): ?>
                                <div class="text-danger">
                                    <?php echo e($error. ' month required'); ?>

                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Progress Bar -->
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                    </div>
                    <?php endfor; ?>
                    <b><br>OR</b>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">

                            <b>Consolidated Statement.</b>
                            <p>If Your Statement Is Not Spilt Between Months But One</p>
                        </div>
                        <div class="col-md-4 text-left">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <label class="control-label mb-10">
                                    </label>
                                    <br>
                                    <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                                        <input wire:model="share_holder_statement.<?php echo e($shreholder); ?>"
                                            accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                                            type="file" id="vehicleimage" name="" id="">
                                    </label>
                                </div>
                                <?php $__errorArgs = ["share_holder_statement.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>Latest <?php echo e($company_year >= 3 ? '2' : '1'); ?> Years Financial Statement</b>
                            <p>
                                (Income Statement also known as Profit & Loss
                                + Statement of financial position also known as Balance Sheet)
                            </p>
                        </div>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <label class="control-label mb-10">
                                        <label for="">Latest year</label>
                                    </label>
                                    <br>
                                    <input wire:model="share_holder_latest_year.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                </div>
                                <?php $__errorArgs = ["share_holder_latest_year.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                        <?php if(isset($share_holder_company_year[$shreholder]) &&
                        $share_holder_company_year[$shreholder] >= 3): ?>
                        <div class="col-md-3 text-left" style="margin-top: 30px;">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <label class="control-label mb-10">
                                        <label for="">Before year</label>
                                    </label>
                                    <br>
                                    <input wire:model="share_holder_year_before.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                </div>
                                <?php $__errorArgs = ["share_holder_year_before.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>Profitable for the last 2 accounting years</b>
                        </div>
                        <div class="col-md-4" style="margin-top: 30px;">

                            <div class="form-group">

                                <select wire:model="share_holder_profitable_latest_year.<?php echo e($shreholder); ?>"
                                    class="form-select" aria-label="Default select example">
                                    <option value="" hidden>Select</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                <?php $__errorArgs = ["share_holder_profitable_latest_year.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4" style="margin-top: 30px;">
                            <div class="form-group">
                                <select wire:model="share_holder_profitable_before_year.<?php echo e($shreholder); ?>"
                                    class="form-select" aria-label="Default select example">
                                    <option value="" hidden>Select</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                <?php $__errorArgs = ["share_holder_profitable_before_year.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b style="color: grey;">Optional info</b>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>Current Year.</b>
                            <p>If you are <b>more than 3-6 months into your current accounting year,</b> and
                                if
                                your
                                management account(drafts/unaudited) pulls up the average, providing them
                                may be
                                helpful
                            </p>
                        </div>
                        <div class="col-md-3 text-left">
                            <div x-data="{ isUploading: false, progress: 0 }"
                                x-on:livewire-upload-start="isUploading = true"
                                x-on:livewire-upload-finish="isUploading = false"
                                x-on:livewire-upload-error="isUploading = false"
                                x-on:livewire-upload-progress="progress = $event.detail.progress">
                                <div class="form-group">
                                    <label class="control-label mb-10">
                                    </label>
                                    <br>
                                    <input wire:model="share_holder_current_year.<?php echo e($shreholder); ?>"
                                        accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps" type="file"
                                        id="vehicleimage" name="" id="">
                                </div>
                                <?php $__errorArgs = ["share_holder_current_year.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div x-show="isUploading">
                                    <progress max="100" x-bind:value="progress"></progress>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12" style="margin-top: 30px;">
                            <b>Revenue (rounded up is fine)</b>
                        </div>
                        <div class="col-md-3" style="margin-top: 30px;">
                            <div class="form-group">
                                <input type="number" class="form-control" wire:model="share_holder_optional_revenuee">
                                <?php $__errorArgs = ["share_holder_optional_revenuee.$shreholder"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;">
                                    <?php $message = preg_replace('/[0-9]+/', '', $message); ?>
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <button class="btn" type="button" wire:target='share_holder_document_store'
                                wire:click.prevent='company_share_holder_documents_store(<?php echo e($shreholder); ?>)'>
                                <span wire:loading wire:target="share_holder_document_store"
                                    class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                Save & Continue
                            </button>
                        </div>
                    </div>
                    
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    </div>
    </div>
    </div>
    <script>
        $(document).on('click', '.singleCheck', function () {
            $('.singleCheck').not(this).prop('checked', false);
        });
        $(document).on('click', '.reasonCheck', function () {
            $('.reasonCheck').not(this).prop('checked', false);
        });

    </script>
    <script>
        window.addEventListener('name-updated', event => {
            Swal.fire({
                title: event.detail.newName,
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: 'Update',
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.value) {
                    // calling destroy method to delete
                    window.livewire.find('<?php echo e($_instance->id); ?>').call('shareholderDelete')
                    // success response

                } else {

                }
            })
        })

    </script>
    <script>
        window.addEventListener('confirmation', event => {
            Swal.fire({
                title: event.detail.message,
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: 'Update',
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.value) {
                    // calling destroy method to delete
                    window.livewire.find('<?php echo e($_instance->id); ?>').call(event.detail.function)
                    // success response

                } else {

                }
            })
        })

    </script>
    </section>

    </div>
<?php /**PATH D:\Find-the-loan\resources\views/livewire/cms/apply-loan.blade.php ENDPATH**/ ?>