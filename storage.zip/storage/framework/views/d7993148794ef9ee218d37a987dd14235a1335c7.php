<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="ThemeStarz">
    
    <?php echo $__env->make('cms.pages.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body data-spy="scroll" data-target=".navbar" class="has-loading-screen">
<div class="ts-page-wrapper" id="page-top">
<?php echo $__env->make('cms.pages.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo e($slot); ?>

    <?php echo $__env->make('cms.pages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!--end page-->
<?php echo $__env->make('cms.pages.footer-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAs45RA1WjaLHCScHiERJ0v2c3I3R6ddT4&callback=initAutocomplete&libraries=places&v=weekly"
      async
    ></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
window.livewire.on('alert', param => {
    toastr.success(param['message'])
});
window.livewire.on('danger', param => {
    toastr.error(param['message'])
});
</script>

</body>
</html>
<?php /**PATH D:\Find-the-loan\resources\views/cms/layouts/master.blade.php ENDPATH**/ ?>