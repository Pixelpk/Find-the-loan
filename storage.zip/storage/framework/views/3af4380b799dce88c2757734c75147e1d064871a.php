<script>
    if( document.getElementsByClassName("ts-full-screen").length ) {
        document.getElementsByClassName("ts-full-screen")[0].style.height = window.innerHeight + "px";
    }
</script>
<script src="<?php echo e(asset('assets/cms/js/jquery-3.3.1.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/cms/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/imagesloaded.pkgd.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/cms/js/isInViewport.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/scrolla.jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/jquery-validate.bootstrap-tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/cms/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<!--Google map-->


<script>
    function showNotificationModal(message,colorName,placementFrom,placementAlign){
        // if (text === null || text === '') { text = 'Turning standard Bootstrap alerts'; }
        var allowDismiss = true;
        $.notify({
                message: message
            },
            {
                type: colorName,
                allow_dismiss: allowDismiss,
                newest_on_top: true,
                timer: 1000,
                placement: {
                    from: placementFrom,
                    align: placementAlign
                },
                animate: {
                    enter: 'animated fadeInDown',
                    exit: "animated fadeOutUp"
                },
                template: '<div data-notify="container" class="bootstrap-notify-container alert alert-dismissible {0} ' + (allowDismiss ? "p-r-35" : "") + '" role="alert">' +
                    '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                    '<span data-notify="icon"></span> ' +
                    '<span data-notify="title">{1}</span> ' +
                    '<span data-notify="message">{2}</span>' +
                    '<div class="progress" data-notify="progressbar">' +
                    '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
                    '</div>' +
                    '<a href="{3}" target="{4}" data-notify="url"></a>' +
                    '</div>'
            });
    }
</script>

<script>
    function showImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $(input).siblings('.avatar')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(150);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

</script>



<?php /**PATH D:\Find-the-loan\resources\views/cms/pages/footer-js.blade.php ENDPATH**/ ?>