<div>
    <div class="row">
        <div class="col-md-6">
            <div class="col-md-12 text-left">
                <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
                    x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
                    x-on:livewire-upload-progress="progress = $event.detail.progress">
                    <div class="form-group">
                        <label class="control-label mb-10">
                            Tanancy Agreement
                        </label>
                       
                        <?php if($apply_loan): ?>
                        <br>
                        <br>
                           <?php $TA = $gernalInfo->where('key','tanancy_agreement')->where('apply_loan_id', $this->apply_loan->id)->first(); 
                         
                           ?>
                           <a target="blank" href="<?php echo e(Storage::url($TA->value)); ?>"> 
                           <i class="fa fa-file"></i>
                        </a>
                        <?php endif; ?>
                        <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                            <input accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                                wire:model="tanancy_agreement" type="file" id="vehicleimage">

                        </label>
                    </div>
                    <?php $__errorArgs = ['tanancy_agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: red;">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div x-show="isUploading">
                        <progress max="100" x-bind:value="progress"></progress>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                    <b>OR</b>
                    <br>
                    <br>
                <div class="form-check">
                    <input wire:model="user_owned" class="form-check-input" type="checkbox" value="" id="User Owned">
                    <label class="form-check-label" for="User Owned">
                        User Owned
                    </label>
                </div>
            </div>
            <div class="col-md-12 text-left">
                <div x-data="{ isUploading: false, progress: 0 }" x-on:livewire-upload-start="isUploading = true"
                    x-on:livewire-upload-finish="isUploading = false" x-on:livewire-upload-error="isUploading = false"
                    x-on:livewire-upload-progress="progress = $event.detail.progress">
                    <div class="form-group">
                        <label class=""><br>
                            Renovation Quotation
                        </label>
                        <br>
                        <br>
                        <i class="fa fa-file"></i>
                        <label wire:ignore class="label" data-toggle="tooltip" title="Select Image">
                            <input accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
                                wire:model="renovation_quotation" type="file" id="vehicleimage">

                        </label>
                    </div>
                    <?php $__errorArgs = ['renovation_quotation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: red;">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div x-show="isUploading">
                        <progress max="100" x-bind:value="progress"></progress>
                    </div>
                </div>
            </div>
          
            <div class="col-md-12" style="margin-top: 30px;">
                <label for="amount" class="form-label">Amount</label>
                <input wire:model="amount" type="text" class="form-control" id="amount">
                <?php $__errorArgs = ["amount"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           
            
        </div>
        <div class="col-md-6" >
            <div wire:ignore.self class="col-md-12" style="margin-top: 30px;">
                <label for="address" class="form-label">Address</label>
                <input onkeyup="dddd()"  wire:model.defer="address" type="text" class="form-control" id="ship-address1">
                <?php $__errorArgs = ["address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
            <div class="col-md-12" style="margin-top: 30px;">
                <label for="unit" class="form-label">Unit if any
                </label>
                <input wire:model="unit" type="text" class="form-control" id="unit">
                <?php $__errorArgs = ["unit"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-12" style="margin-top: 30px;">
                <label for="building_name" class="form-label">Building name if any
                </label>
                <input wire:model="building_name" type="text" class="form-control" id="building_name">
                <?php $__errorArgs = ["building_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: red;">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-12">
            <br>
            <button class="btn" type="button" wire:target="store" wire:click.prevent="store">
                <span wire:loading="" wire:target="store" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Save &amp; Continue
            </button>
        </div>
    </div>


<?php /**PATH D:\Find-the-loan\resources\views/livewire/widget/renovation.blade.php ENDPATH**/ ?>